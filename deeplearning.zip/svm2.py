#Import Library
#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
# Create SVM classification object
from sklearn import svm
import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm

x = np.arange(0,10,0.1)
number1=np.random.normal(x,3)
number2=np.random.normal(x,3)
y1= x+number1
y2=x+11+number2
print(type(x))
fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.set_title('Scatter Plot')
plt.xlabel('X')
plt.ylabel('Y')
ax1.scatter(x,y1,c = 'r',marker = 'o')
ax1.scatter(x,y2,c = 'g',marker = 'x')
plt.legend('x1')

c1=np.vstack((x,y1))
c2=np.vstack((x,y2))
c3=np.hstack((c1,c2))
d1=np.ones(100,int)
d2=np.zeros(100,int)
d3=np.hstack((d1,d2)).reshape((200,1))
X=c3.transpose()
y=d3
#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
# Create SVM classification object
model = svm.SVC(C=0.01,kernel='linear')
# there is various option associated with it, like changing kernel, gamma and C value. Will discuss more # about it in next section.Train the model using the training sets and check score
model.fit(X, y)
#Predict Output
w=model.coef_[0]
a=-w[0]/w[1]
xx = np.linspace(0, 10)  # (0,10)之间x的值
yy = a * xx - (model.intercept_[0]) / w[1]  # xx带入y，截距
print("W:", w)
print("a:", a)#斜率
# 画出与点相切的线
b = model.support_vectors_[0]
print(b)
yy_down = a * xx + (b[1] - a * b[0])#下边
b = model.support_vectors_[-1]
yy_up = a * xx + (b[1] - a * b[0])#上边

plt.figure(figsize=(8, 4))
plt.plot(xx, yy)
plt.plot(xx, yy_down)
plt.plot(xx, yy_up)
plt.scatter(model.support_vectors_[:, 0], model.support_vectors_[:, 1], s=80)
plt.scatter(X[:,0], X[:, 1], c='g', cmap=plt.cm.Paired)  # [:，0]列切片，第0列
plt.axis('tight')
plt.show()



