import numpy as np
import matplotlib.pyplot as plt

x = np.arange(0,10,0.1)#平均取100个点
number1=np.random.normal(x,3)#取得标准差为3的噪声值
number2=np.random.normal(x,3)
y1=x+number1
y2=x++20+number2
fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.set_title('Scatter Plot')
plt.xlabel('X')#对x轴做标记
plt.ylabel('Y')#对y轴做标记
ax1.scatter(x,y1,c = 'r',marker = 'o')#画散点图
ax1.scatter(x,y2,c = 'g',marker = 'x')
plt.legend('x1')
plt.show()
