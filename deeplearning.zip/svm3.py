import matplotlib.pyplot as plt
import numpy as np
from sklearn import svm
#此为绘制超平面的函数；
def plot_hyperplane(clf, X, y,h=0.02,draw_sv=True,title='hyperplan'):
    # create a mesh to plot in
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    plt.title(title)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.xticks(())
    plt.yticks(())

    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    # Put the result into a color plot
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, cmap='hot', alpha=0.5)

    markers = ['o', 's', '^']
    colors = ['b', 'r', 'c']
    labels = np.unique(y)
    for label in labels:
        plt.scatter(X[:, 0],
                    X[:, 1],
                    c=colors[label],
                    marker=markers[label])
    if draw_sv:
        sv = clf.support_vectors_
        plt.scatter(sv[:, 0], sv[:, 1], c='y', marker='x')


fig = plt.figure()
ax1 = fig.add_subplot(111)
X1 = np.random.multivariate_normal(mean=[0,0], cov=[[1, 0], [0,1]], size = 300)
X2 = np.random.multivariate_normal(mean=[7,7], cov=[[1, 0], [0,1]], size = 300)
ax1.scatter(X1[:,0], X1[:,1])
ax1.scatter(X2[:,0],X2[:,1])
X3=np.hstack((X1.transpose(),X2.transpose()))
d1=np.ones(300,int)
d2=np.zeros(300,int)
d3=np.hstack((d1,d2)).reshape((600,1))
X=X3.transpose()
y=d3
clf_linear = svm.SVC(C=0.1,kernel='poly', degree=2)
clf_poly = svm.SVC(C=0.1, kernel='poly', degree=3)
clf_rbf = svm.SVC(C=0.1, kernel='rbf', gamma=0.5)
clf_rbf2 = svm.SVC(C=0.1, kernel='rbf', gamma=0.1)

plt.figure(figsize=(10, 10), dpi=144)

clfs = [clf_linear, clf_poly, clf_rbf]
titles = ['Polynomial Kernel with Degree=2',
          'Polynomial Kernel with Degree=3',
          'Gaussian Kernel with $\gamma=0.5$']
for clf, i in zip(clfs, range(len(clfs))):
    clf.fit(X, y)
    plt.subplot(2, 2, i+1)
    plot_hyperplane(clf, X, y, title=titles[i])

plt.show()