import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
ax1 = fig.add_subplot(111)
#参数中设置均值，相关系数，散点个数
X1 = np.random.multivariate_normal(mean=[0,0], cov=[[1, 0], [0,1]], size = 300)
X2 = np.random.multivariate_normal(mean=[7,7], cov=[[1, 0], [0,1]], size = 300)
ax1.scatter(X1[:,0], X1[:,1])
ax1.scatter(X2[:,0],X2[:,1])
plt.show()

