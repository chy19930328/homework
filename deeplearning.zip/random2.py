import numpy as np
import matplotlib.pyplot as plt

x = np.arange(1,10,0.1)
number1=np.random.normal(x,3)
number2=np.random.normal(x,3)
y1= x+number1
y2=x+11+number2
fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.set_title('Scatter Plot')
plt.xlabel('X')
plt.ylabel('Y')
ax1.scatter(x,y1,c = 'r',marker = 'o')
ax1.scatter(x,y2,c = 'g',marker = 'x')
plt.legend('x1')
plt.show()